EXERCISE 1
==========

## 1)
Several instances of the DNS (domain name system), TCP(transmission control protocol) and TLS (transport layer security) appear.

## 2)
It took about 136ms from the GET request being sent to the OK was received.

## 3)
The destination address is  128.119.245.12 while my local IP address is 10.22.1.47.

